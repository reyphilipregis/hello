<html>
    <head>
        <title>Hello Laravel</title>
    </head>
    <body>
        <h1>Hello Laravel</h1>
    </body>
</html>
<?php /**PATH /Users/reyphilipregis/Documents/hello/resources/views/welcome.blade.php ENDPATH**/ ?>